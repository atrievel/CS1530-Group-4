<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Edit Profile              _1</name>
   <tag></tag>
   <elementGuidId>55610163-52fc-4c37-b1ec-0350ae2e5043</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>modal fade show</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>modalEditProfile</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tabindex</name>
      <type>Main</type>
      <value>-1</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>role</name>
      <type>Main</type>
      <value>dialog</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
            
                
                    
                        Edit Profile
                        
                            ×
                        
                    
                    
                        
                            Name:
                            
                            
                                Looks good!
                            
                            
                                Name cannot be blank
                            
                        
                        
                            Email:
                            
                            
                                Looks good!
                            
                            
                                Email cannot be blank
                            
                        
                        
                            Password:
                            
                            
                                Looks good!
                            
                            
                                Passwords must be 8 or more characters long and match
                            
                        
                        
                            Confirm Password:
                            
                            
                                Looks good!
                            
                            
                                Passwords must be 8 or more characters long and match
                            
                        
                        
                            Bio:
                            
                            
                                Looks good!
                            
                            
                                Bio must be less than 256 characters
                            
                        
                    
                    
                        Update Profile
                    
                
            
        </value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;modalEditProfile&quot;)</value>
   </webElementProperties>
</WebElementEntity>
