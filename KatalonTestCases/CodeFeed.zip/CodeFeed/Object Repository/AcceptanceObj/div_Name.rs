<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Name</name>
   <tag></tag>
   <elementGuidId>df160f98-2639-4a80-ae8d-f84e0e3584d4</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>modal-body</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                        
                            Name:
                            
                            
                                Looks good!
                            
                            
                                Name cannot be blank
                            
                        
                        
                            Email:
                            
                            
                                Looks good!
                            
                            
                                Email cannot be blank
                            
                        
                        
                            Password:
                            
                            
                                Looks good!
                            
                            
                                Passwords must be 8 or more characters long and match
                            
                        
                        
                            Confirm Password:
                            
                            
                                Looks good!
                            
                            
                                Passwords must be 8 or more characters long and match
                            
                        
                        
                            Bio:
                            
                            
                                Looks good!
                            
                            
                                Bio must be less than 256 characters
                            
                        
                    </value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;modalEditProfile&quot;)/div[@class=&quot;modal-dialog&quot;]/div[@class=&quot;modal-content&quot;]/div[@class=&quot;modal-body&quot;]</value>
   </webElementProperties>
</WebElementEntity>
